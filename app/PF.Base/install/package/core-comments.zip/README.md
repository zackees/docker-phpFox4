# Comments

## App Info

- `App name`: Comments
- `Version`: 4.1.12
- `Link on Store`: https://store.phpfox.com/
- `Demo site`: https://v4.phpfox.com
- `Owner`: phpFox

## Installation Guide

Please follow below steps to install new phpFox Comments app:

1. Install the Comments App from the store.

2. Remove files no longer used (at Admin Panel > Maintenance > Remove files no longer used).

3. Clear `Cache` and `Rebuild Core Theme` on your site.

Congratulation! You have completed installation process.