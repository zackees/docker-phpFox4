<?php

namespace Apps\Core_Comments\Job;

use Core\Queue\JobAbstract;
use Phpfox;

/**
 * Class DeleteForItem
 *
 * @package Apps\Core_Comments\Job
 */
class DeleteForItem extends JobAbstract
{
    /**
     * @inheritdoc
     */
    public function perform()
    {
        $aParams = $this->getParams();
        Phpfox::getService('comment.process')->deleteForItem($aParams['user_id'], $aParams['item_id'], $aParams['type_id'], true);
        $this->delete();
    }
}
