<?php 
/**
 * [PHPFOX_HEADER]
 * 
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		phpFox LLC
 * @package 		Phpfox
 * @version 		$Id: rss.html.php 706 2009-06-22 11:36:16Z phpFox LLC $
 */
 
defined('PHPFOX') or exit('NO DICE!'); 

?>