<?php
\Core\Queue\Manager::instance()->addHandler('comment_delete_for_item', '\Apps\Core_Comments\Job\DeleteForItem');
