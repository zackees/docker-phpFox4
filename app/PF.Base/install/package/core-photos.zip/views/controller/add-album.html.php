<?php

defined('PHPFOX') or exit('NO DICE!');

?>
<div id="js_actual_upload_form">
    <form method="post" action="{url link='current'}" enctype="multipart/form-data" id="js_photo_add_album_form">
        {template file='photo.block.form-album'}
        <input type="submit" value="{_p var='submit'}" class="btn btn-primary" />
    </form>
</div>
