<?php
$aPluginFiles[] = 'PF.Base/module/photo/';
$aPluginFiles[] = 'PF.Site/Apps/core-photos/assets/autoload.css';