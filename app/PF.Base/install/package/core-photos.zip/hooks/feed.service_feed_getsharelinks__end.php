<?php
if ((!Phpfox::getParam('photo.photo_allow_create_feed_when_add_new_item') || !Phpfox::getUserParam('photo.can_view_photos'))&& isset($aAcceptedTypes)) {
    foreach ($aAcceptedTypes as $key => $acceptedType) {
        if ($acceptedType == 'photo') {
            unset($aAcceptedTypes[$key]);
            break;
        }
    }
}