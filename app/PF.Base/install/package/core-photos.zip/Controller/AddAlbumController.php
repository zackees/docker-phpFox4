<?php

namespace Apps\Core_Photos\Controller;

use Phpfox;
use Phpfox_Component;
use Phpfox_Error;
use Phpfox_Plugin;

defined('PHPFOX') or exit('NO DICE!');

class AddAlbumController extends Phpfox_Component
{
    public function process()
    {
        Phpfox::isUser(true);
        Phpfox::getUserParam('photo.can_view_photos', true);
        Phpfox::getUserParam('photo.can_create_photo_album', true);

        $sModule = $this->request()->get('module', null);
        $iItem = $this->request()->getInt('item', 0);

        $iTotalAlbums = Phpfox::getService('photo.album')->getAlbumCount(Phpfox::getUserId());
        $bAllowedAlbums = (Phpfox::getUserParam('photo.max_number_of_albums') == '' ? true : (!Phpfox::getUserParam('photo.max_number_of_albums') ? false : (Phpfox::getUserParam('photo.max_number_of_albums') <= $iTotalAlbums ? false : true)));

        if (!$bAllowedAlbums) {
            return Phpfox_Error::set(_p('you_have_reached_your_limit_you_are_currently_unable_to_create_new_photo_albums'));
        }

        if ($sModule && $iItem
            && Phpfox::hasCallback($sModule, 'getPhotoDetails')
            && !empty($aParentInfo = Phpfox::callback($sModule . '.getPhotoDetails', ['group_id' => $iItem]))) {
            $this->template()->setBreadCrumb($aParentInfo['breadcrumb_title'], $aParentInfo['breadcrumb_home'])
                ->setBreadCrumb($aParentInfo['title'], $aParentInfo['url_home'])
                ->setBreadCrumb(_p('albums'), rtrim($aParentInfo['url_home_photo'], '/') . '/albums/');
            $addAlbumUrl = $this->url()->makeUrl('photo.add-album', [
                'module' => $sModule,
                'item' => $iItem,
            ]);
        } else {
            $this->template()->setBreadCrumb(_p('photos'), $this->url()->makeUrl('photo'));
            $addAlbumUrl = $this->url()->makeUrl('photo.add-album');
        }

        if (($aVals = $this->request()->getArray('val'))) {
            $oValid = Phpfox::getLib('validator')->set([
                'sFormName' => 'js_photo_add_album_form',
                'aParams' => [
                    'name' => [
                        'def' => 'string:required',
                        'title' => _p('fill_name_for_the_album')
                    ],
                ]
            ]);

            $aVals['module_id'] = $sModule;
            $aVals['group_id'] = $iItem;

            if ($oValid->isValid($aVals) && $iAlbumId = Phpfox::getService('photo.album.process')->add($aVals)) {
                $this->url()->permalink('photo.album', $iAlbumId, null, true, _p('photo.album_successfully_created'));
            }
        }

        $this->template()->setTitle(_p('create_album'))
            ->setBreadCrumb(_p('create_album'), $addAlbumUrl, true)
            ->assign([
                'sModule' => $sModule
            ]);
        return null;
    }

    /**
     * Garbage collector. Is executed after this class has completed
     * its job and the template has also been displayed.
     */
    public function clean()
    {
        (($sPlugin = Phpfox_Plugin::get('photo.component_controller_add_album_clean')) ? eval($sPlugin) : false);
    }
}